/*
*********************************************************************************************************
*                                                 uC/OS-II
*                                          The Real-Time Kernel
*                                               PORT Windows
*
*
*            				  Arnaud Desault, Fr�d�ric Fortier, Eva Terriault
*								�cole Polytechnique de Montreal, QC, CANADA
*                                                  08/2017
*
* File : exo4b.c
* 
*********************************************************************************************************
*/

// Main include of �C-II
#include "includes.h"

/*
*********************************************************************************************************
*                                              CONSTANTS
*********************************************************************************************************
*/

#define TASK_STK_SIZE       16384            // Size of each task's stacks (# of WORDs)

#define ROBOT_A_PRIO   		9				 // Defining Priority of each task
#define ROBOT_B_PRIO   		8
#define CONTROLLER_PRIO     7
#define TRANSPORT_PRIO		10

#define TIME_OP_PRIO		6

/*
*********************************************************************************************************
*                                             VARIABLES
*********************************************************************************************************
*/

OS_STK           prepRobotAStk[TASK_STK_SIZE];	//Stack of each task
OS_STK           prepRobotBStk[TASK_STK_SIZE];
OS_STK           transportStk[TASK_STK_SIZE];
OS_STK           controllerStk[TASK_STK_SIZE];

/*
*********************************************************************************************************
*                                           SHARED  VARIABLES
*********************************************************************************************************
*/
OS_EVENT* sem_prep_to_transport;
OS_EVENT* sem_transport_done;
OS_EVENT* mutex_time_op;

OS_EVENT* q_prep_A;
OS_EVENT* q_prep_B;
OS_EVENT* q_transport;

volatile int total_prep_time = 0;

volatile void *prep_A_msg[10];
volatile void *prep_B_msg[10];
volatile void *transport_msg[10];

/*
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*********************************************************************************************************
*/
void	prep_robot(void *data);
void    transport(void *data);
void    controller(void *data);
void    errMsg(INT8U err, char* errMSg);
int		readCurrentTotalPrepTime();
void	writeCurrentTotalPrepTime(int qty);

/*
*********************************************************************************************************
*                                                  MAIN
*********************************************************************************************************
*/

void main(void)
{

	UBYTE err;

	char* robot_arg;

	// A compl�ter
	OSInit();

	err = (OSTaskCreate(*controller, NULL, &controllerStk[TASK_STK_SIZE - 1], CONTROLLER_PRIO));
	errMsg(err, "Error lors de la cr�ation de la t�che du contr�leur.");

	err = (OSTaskCreate(*prep_robot, (void *) robot_arg = "A", &prepRobotAStk[TASK_STK_SIZE - 1], ROBOT_A_PRIO));
	errMsg(err, "Error lors de la cr�ation de la t�che de pr�paration du robot A.");

	err = (OSTaskCreate(*prep_robot, (void *) robot_arg = "B", &prepRobotBStk[TASK_STK_SIZE - 1], ROBOT_B_PRIO));
	errMsg(err, "Error lors de la cr�ation de la t�che de pr�paration du robot B.");

	err = (OSTaskCreate(*transport, NULL, &transportStk[TASK_STK_SIZE - 1], TRANSPORT_PRIO));
	errMsg(err, "Error lors de la cr�ation de la t�che du transport.");

	if (!(sem_prep_to_transport = OSSemCreate(0))) {
		printf("Erreur lors de la cr�ation du s�maphore de transport pr�t.");
		exit(1);
	}

	if (!(sem_transport_done = OSSemCreate(2))) {
		printf("Erreur lors de la cr�ation du s�maphore de transport termin�.");
		exit(1);
	}

	if (!(q_prep_A = OSQCreate(&prep_A_msg[0], 10))) {
		printf("Erreur lors de la cr�ation de la file pour le robot A.");
		exit(1);
	}

	if (!(q_prep_B = OSQCreate(&prep_B_msg[0], 10))) {
		printf("Erreur lors de la cr�ation de la file pour le robot B.");
		exit(1);
	}

	if (!(q_transport = OSQCreate(&transport_msg[0], 10))) {
		printf("Erreur lors de la cr�ation de la file pour le transport.");
		exit(1);
	}

	mutex_time_op = OSMutexCreate(TIME_OP_PRIO, &err);
	errMsg(err, "Error lors de la cr�ation du mutex de lecture/�criture du temps.");



	OSStart();

	return;
}

/*
*********************************************************************************************************
*                                            TASK FUNCTIONS
*********************************************************************************************************
*/

void prep_robot(void* data)
{
	INT8U err;
	int startTime = 0;
	int orderNumber = 1;
	int *robotPrepTime;
	printf("TACHE PREP_ROBOT_%s @ %d : DEBUT. \n", (char *) data, OSTimeGet() - startTime);
	while (1)
	{

		OSSemPend(sem_transport_done, 0, &err);
		errMsg(err, "Error while trying to access sem_transport_done");

		if ((char*)data == "A") {
			robotPrepTime = OSQPend(q_prep_A, 0, &err);
		}
		else if ((char*)data == "B") {
			robotPrepTime = OSQPend(q_prep_B, 0, &err);
		}
		else {
			printf("Erreur lors du transfert de donn�es vers les t�ches des robots.");
			exit(1);
		}
		errMsg(err, "Error while trying to access q_prep_a or q_prep_b");

		printf("TACHE PREP_ROBOT_%s COMMANDE #%d @ %d : D�but pr�paration robot %s.\n", (char*) data, orderNumber, OSTimeGet() - startTime, (char*) data);
		OSTimeDly(*robotPrepTime);
		printf("TACHE PREP_ROBOT_%s COMMANDE #%d @ %d : Fin pr�paration robot %s.\n", (char*) data, orderNumber, OSTimeGet() - startTime, (char*) data);

		OSMutexPend(mutex_time_op, 0, &err);
		errMsg(err, "Error while trying to access mutex_time_op");

		writeCurrentTotalPrepTime(readCurrentTotalPrepTime() + *robotPrepTime);

		free(robotPrepTime);

		err = OSMutexPost(mutex_time_op);
		errMsg(err, "Error while trying to post mutex_time_op");

		printf("TACHE PREP_ROBOT_%s COMMANDE #%d @ %d : Demande de d�marrage du transport.\n", (char*) data, orderNumber, OSTimeGet() - startTime);

		err = OSSemPost(sem_prep_to_transport);
		errMsg(err, "Error while trying to post sem_prep_to_transport");

		orderNumber++;
	}
}

void transport(void* data)
{
	INT8U err;
	int startTime = 0;
	int orderNumber = 1;
	int *time;
	printf("TACHE TRANSPORT @ %d : DEBUT. \n", OSTimeGet() - startTime);
	while (1)
	{

		// WAIT FOR TWO READY ROBOTS
		OSSemPend(sem_prep_to_transport, 0, &err);
		errMsg(err, "Error while trying to post sem_prep_to_transport");

		OSSemPend(sem_prep_to_transport, 0, &err);
		errMsg(err, "Error while trying to post sem_prep_to_transport");

		time = OSQPend(q_transport, 0, &err);
		errMsg(err, "Error while trying to access q_transport");

		printf("TEMPS TOTAL DE PR�PARATION �COUL� %d.\n", readCurrentTotalPrepTime());

		printf("TACHE TRANSPORT COMMANDE #%d @ %d : D�but transport.\n", orderNumber, OSTimeGet() - startTime);
		OSTimeDly(*time);
		printf("TACHE TRANSPORT COMMANDE #%d @ %d : Fin du transport.\n", orderNumber, OSTimeGet() - startTime);

		free(time);

		// POST FOR TWO ROBOTS
		err = OSSemPost(sem_transport_done);
		errMsg(err, "Error while trying to post sem_transport_done");

		err = OSSemPost(sem_transport_done);
		errMsg(err, "Error while trying to post sem_transport_done");

		orderNumber++;

	}
}
void controller(void* data)
{
INT8U err;
	int startTime = 0;
	int randomTime = 0;
	int *a_prep_time;
	int *b_prep_time;
	int *transport_time;
	printf("TACHE CONTROLLER @ %d : DEBUT. \n", OSTimeGet() - startTime);
	for(int i = 1 ; i < 11; i++)
	{	

		//Cr�ation d'une commande
		a_prep_time = malloc(sizeof(int));
		b_prep_time = malloc(sizeof(int));
		transport_time = malloc(sizeof(int));

		*a_prep_time = (rand() % 8 + 3) * 10;
		*b_prep_time = (rand() % 8 + 6) * 10;
		*transport_time = (rand() % 6 + 9) * 10;

		printf("TACHE CONTROLLER @ %d : COMMANDE #%d. \n prep time A = %d, prep time B = %d, Transport time = %d\n", OSTimeGet() - startTime, i, *a_prep_time, *b_prep_time, *transport_time);

		//� compl�ter
		err = OSQPost(q_prep_A, (void *)a_prep_time);
		errMsg(err, "Error while trying to post to q_prep_A.");

		err = OSQPost(q_prep_B, (void *)b_prep_time);
		errMsg(err, "Error while trying to post to q_prep_B.");

		err =OSQPost(q_transport, (void *)transport_time);
		errMsg(err, "Error while trying to post to q_transport.");
		
		// D�lai al�atoire avant nouvelle commande
		randomTime = (rand() % 9 + 5) * 10;
		OSTimeDly(randomTime);
	}
}

int	readCurrentTotalPrepTime()
{
	OSTimeDly(2);
	return total_prep_time;
}
void writeCurrentTotalPrepTime(int newCount)
{
	OSTimeDly(2);
	total_prep_time = newCount;
}

void errMsg(INT8U err, char* errMsg)
{
	if (err != OS_ERR_NONE)
	{
		printf(errMsg);
		exit(1);
	}
}
